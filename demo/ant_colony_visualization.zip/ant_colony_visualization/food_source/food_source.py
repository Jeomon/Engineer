import pygame

class FoodSource:
    """
    Represents a food source in the ant colony simulation.

    Attributes:
        x (int): The x-coordinate of the food source.
        y (int): The y-coordinate of the food source.
        amount (int): The amount of food available at this source.
    """
    def __init__(self, x, y, amount):
        """
        Initializes a new food source object.

        Args:
            x (int): The x-coordinate of the food source.
            y (int): The y-coordinate of the food source.
            amount (int): The initial amount of food available.
        """
        self.x = x
        self.y = y
        self.amount = amount

    def take_food(self, amount):
        """
        Takes food from the food source.

        Args:
            amount (int): The amount of food to take.

        Returns:
            int: The amount of food actually taken (limited by available amount).
        """
        if self.amount >= amount:
            self.amount -= amount
            return amount
        else:
            taken = self.amount
            self.amount = 0
            return taken

    def draw(self, screen):
        """
        Draws the food source on the screen.

        Args:
            screen (pygame.Surface): The Pygame surface to draw on.
        """
        pygame.draw.circle(screen, (0, 255, 0), (self.x, self.y), 5)  # Green circle for food source