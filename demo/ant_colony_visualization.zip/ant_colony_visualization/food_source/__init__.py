# ./ant_colony_visualization/ant_colony_visualization/food_source/__init__.py

# This file indicates that the 'food_source' directory is a Python package.
# It allows you to import modules from this directory.