# ./ant_colony_visualization/ant_colony_visualization/__init__.py
# This file indicates that the directory should be treated as a Python package.