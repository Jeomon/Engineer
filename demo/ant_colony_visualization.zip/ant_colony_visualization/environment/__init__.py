# ./ant_colony_visualization/ant_colony_visualization/environment/__init__.py

# This file indicates that the 'environment' directory is a Python package.