import pygame

class Environment:
    """
    Represents the environment where the ants move and interact.

    Attributes:
        width (int): The width of the environment.
        height (int): The height of the environment.
        pheromone_grid (list[list[float]]): A 2D grid representing pheromone levels at each location.
        evaporation_rate (float): The rate at which pheromones evaporate.
    """

    def __init__(self, width: int, height: int, evaporation_rate: float):
        """
        Initializes the environment with a given width, height, and pheromone evaporation rate.

        Args:
            width (int): The width of the environment.
            height (int): The height of the environment.
            evaporation_rate (float): The rate at which pheromones evaporate per step.
        """
        self.width = width
        self.height = height
        self.pheromone_grid = [[0.0 for _ in range(width)] for _ in range(height)]
        self.evaporation_rate = evaporation_rate

    def deposit_pheromone(self, x: int, y: int, amount: float):
        """
        Deposits a pheromone at the specified coordinates.

        Args:
            x (int): The x-coordinate of the location to deposit pheromone.
            y (int): The y-coordinate of the location to deposit pheromone.
            amount (float): The amount of pheromone to deposit.
        """
        # Check for valid coordinates
        if 0 <= x < self.width and 0 <= y < self.height:
            self.pheromone_grid[y][x] = min(1.0, self.pheromone_grid[y][x] + amount)  # Cap pheromone level at 1.0
        # else:
        #     print(f"Warning: Invalid coordinates for pheromone deposit: ({x}, {y})")

    def evaporate_pheromones(self):
        """
        Evaporates pheromones in the environment.  Each cell's pheromone level is reduced by the evaporation rate.
        """
        for y in range(self.height):
            for x in range(self.width):
                self.pheromone_grid[y][x] = max(0.0, self.pheromone_grid[y][x] - self.evaporation_rate)  # Ensure pheromone level doesn't go below 0.0

    def get_pheromone_level(self, x: int, y: int) -> float:
        """
        Gets the pheromone level at the specified coordinates.

        Args:
            x (int): The x-coordinate of the location.
            y (int): The y-coordinate of the location.

        Returns:
            float: The pheromone level at the specified coordinates.  Returns 0.0 if the coordinates are out of bounds.
        """
        if 0 <= x < self.width and 0 <= y < self.height:
            return self.pheromone_grid[y][x]
        else:
            return 0.0  # Return 0 for out-of-bounds access

    def draw(self, screen: pygame.Surface):
        """
        Draws the pheromone trails on the screen.  The intensity of the color represents the pheromone level.

        Args:
            screen (pygame.Surface): The Pygame surface to draw on.
        """
        for y in range(self.height):
            for x in range(self.width):
                pheromone_level = self.pheromone_grid[y][x]
                if pheromone_level > 0:
                    color = (int(255 * pheromone_level), int(255 * pheromone_level), int(255 * pheromone_level))  # Grayscale representation
                    screen.set_at((x, y), color)