import pygame

class Colony:
    """
    Represents the ant colony.
    
    Attributes:
        x (int): The x-coordinate of the colony.
        y (int): The y-coordinate of the colony.
        food_storage (int): The amount of food stored in the colony.
    """
    def __init__(self, x, y):
        """
        Initializes a new Colony object.

        Args:
            x (int): The x-coordinate of the colony.
            y (int): The y-coordinate of the colony.
        """
        self.x = x
        self.y = y
        self.food_storage = 0

    def store_food(self, amount):
        """
        Stores food in the colony.

        Args:
            amount (int): The amount of food to store.
        """
        if not isinstance(amount, (int, float)):
            raise TypeError("Amount must be a number.")
        if amount < 0:
            raise ValueError("Amount must be non-negative.")
        self.food_storage += amount

    def draw(self, screen):
        """
        Draws the colony on the screen.

        Args:
            screen (pygame.Surface): The Pygame surface to draw on.
        """
        pygame.draw.circle(screen, (0, 0, 255), (self.x, self.y), 10)  # Blue circle for colony