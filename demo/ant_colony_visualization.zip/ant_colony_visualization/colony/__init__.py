# ./ant_colony_visualization/ant_colony_visualization/colony/__init__.py

# This file indicates that the 'colony' directory is a Python package.