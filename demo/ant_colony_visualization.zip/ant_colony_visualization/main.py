import pygame
import sys
import random

# Import user-defined modules
from environment import environment
from ant import ant
from colony import colony
from food_source import food_source

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
NUM_ANTS = 50
FOOD_SOURCES = 3
PHEROMONE_EVAPORATION_RATE = 0.005
ANT_SPEED = 2

# Screen setup
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ant Colony Optimization Visualization")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

# Initialize environment
environment_instance = environment.Environment(WIDTH, HEIGHT, PHEROMONE_EVAPORATION_RATE)

# Initialize colony
colony_instance = colony.Colony(WIDTH // 2, HEIGHT // 2)

# Initialize ants
ants = []
for _ in range(NUM_ANTS):
    ants.append(ant.Ant(colony_instance.x, colony_instance.y, ANT_SPEED))

# Initialize food sources
food_sources_list = []
for _ in range(FOOD_SOURCES):
    x = random.randint(0, WIDTH)
    y = random.randint(0, HEIGHT)
    food_sources_list.append(food_source.FoodSource(x, y, 1000))  # Initial food amount

# Main simulation loop
running = True
while running:
    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update game logic
    for ant_instance in ants:
        ant_instance.move(environment_instance)
        food = ant_instance.detect_food(food_sources_list)
        if food:
            ant_instance.carry_food()
            food_amount = food.take_food(10)  # Take some food
            if food_amount > 0:
                ant_instance.carry_food()
            else:
                pass # Food source is empty
        if ant_instance.has_food:
            ant_instance.return_to_colony(colony_instance)
            if abs(ant_instance.x - colony_instance.x) < 5 and abs(ant_instance.y - colony_instance.y) < 5:
                colony_instance.store_food(10)
                ant_instance.deposit_food(colony_instance)

        ant_instance.lay_pheromone(environment_instance)

    environment_instance.evaporate_pheromones()

    # Render the simulation
    screen.fill((0, 0, 0))  # Black background
    environment_instance.draw(screen)
    colony_instance.draw(screen)
    for food_source_instance in food_sources_list:
        food_source_instance.draw(screen)
    for ant_instance in ants:
        ant_instance.draw(screen)

    # Update the display
    pygame.display.flip()

    # Control the frame rate
    clock.tick(60)

# Quit Pygame
pygame.quit()
sys.exit()