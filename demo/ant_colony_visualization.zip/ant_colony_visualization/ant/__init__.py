# ./ant_colony_visualization/ant_colony_visualization/ant/__init__.py

# This file indicates that the 'ant' directory should be treated as a Python package.
# It can be empty or contain initialization code for the 'ant' package.