import pygame
import random
import math

class Ant:
    """
    Represents an ant in the simulation.

    Attributes:
        x (int): The x-coordinate of the ant.
        y (int): The y-coordinate of the ant.
        direction (float): The direction the ant is facing in radians.
        has_food (bool): Whether the ant is carrying food.
        speed (int): The speed of the ant.
    """

    random_move_probability = 0.05  # Probability of the ant moving randomly

    def __init__(self, x, y, speed):
        """
        Initializes a new ant object.

        Args:
            x (int): The x-coordinate of the ant.
            y (int): The y-coordinate of the ant.
            speed (int): The speed of the ant.
        """
        self.x = x
        self.y = y
        self.direction = random.uniform(0, 2 * math.pi)  # Initial direction is random
        self.has_food = False
        self.speed = speed

    def move(self, environment):
        """
        Moves the ant based on pheromone trails and random movement.

        Args:
            environment (Environment): The environment the ant is moving in.
        """
        # Check for random movement
        if random.random() < Ant.random_move_probability:
            self.direction += random.uniform(-math.pi / 4, math.pi / 4)  # Slight random turn

        # Pheromone-guided movement
        else:
            # Get pheromone levels in front, left, and right
            front_x = int(self.x + math.cos(self.direction) * 10)
            front_y = int(self.y + math.sin(self.direction) * 10)
            left_x = int(self.x + math.cos(self.direction - math.pi / 6) * 10)
            left_y = int(self.y + math.sin(self.direction - math.pi / 6) * 10)
            right_x = int(self.x + math.cos(self.direction + math.pi / 6) * 10)
            right_y = int(self.y + math.sin(self.direction + math.pi / 6) * 10)

            # Ensure the coordinates are within the environment bounds
            width, height = environment.width, environment.height
            front_x = max(0, min(front_x, width - 1))
            front_y = max(0, min(front_y, height - 1))
            left_x = max(0, min(left_x, width - 1))
            left_y = max(0, min(left_y, height - 1))
            right_x = max(0, min(right_x, width - 1))
            right_y = max(0, min(right_y, height - 1))

            front_pheromone = environment.get_pheromone_level(front_x, front_y)
            left_pheromone = environment.get_pheromone_level(left_x, left_y)
            right_pheromone = environment.get_pheromone_level(right_x, right_y)

            # Turn towards the strongest pheromone signal
            if front_pheromone >= left_pheromone and front_pheromone >= right_pheromone:
                pass  # Continue straight
            elif left_pheromone > front_pheromone and left_pheromone > right_pheromone:
                self.direction -= math.pi / 12  # Turn left slightly
            else:
                self.direction += math.pi / 12  # Turn right slightly

        # Move the ant
        self.x += math.cos(self.direction) * self.speed
        self.y += math.sin(self.direction) * self.speed

        # Keep the ant within the environment bounds (wrap around)
        self.x %= environment.width
        self.y %= environment.height

    def lay_pheromone(self, environment):
        """
        Lays down a pheromone at the ant's current position.

        Args:
            environment (Environment): The environment the ant is in.
        """
        environment.deposit_pheromone(int(self.x), int(self.y), 1.0)

    def detect_food(self, food_sources):
        """
        Detects food sources near the ant.

        Args:
            food_sources (list): A list of FoodSource objects.

        Returns:
            FoodSource or None: The food source detected, or None if no food source is nearby.
        """
        for food_source in food_sources:
            distance = math.sqrt((self.x - food_source.x)**2 + (self.y - food_source.y)**2)
            if distance < 20:  # Detection range
                return food_source
        return None

    def carry_food(self):
        """
        Sets the ant's food carrying status to True.
        """
        self.has_food = True

    def return_to_colony(self, colony):
        """
        Guides the ant back to the colony.

        Args:
            colony (Colony): The colony to return to.
        """
        angle_to_colony = math.atan2(colony.y - self.y, colony.x - self.x)
        self.direction = angle_to_colony

        # Move towards the colony
        self.x += math.cos(self.direction) * self.speed
        self.y += math.sin(self.direction) * self.speed

    def deposit_food(self, colony):
        """
        Deposits food at the colony.

        Args:
            colony (Colony): The colony to deposit food at.
        """
        colony.store_food(1)  # Deposit 1 unit of food
        self.has_food = False

    def draw(self, screen):
        """
        Draws the ant on the screen.

        Args:
            screen (pygame.Surface): The screen to draw on.
        """
        color = (255, 0, 0) if self.has_food else (0, 0, 255)  # Red if carrying food, blue otherwise
        pygame.draw.circle(screen, color, (int(self.x), int(self.y)), 5)